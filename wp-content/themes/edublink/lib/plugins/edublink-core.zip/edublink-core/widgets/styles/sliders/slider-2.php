<div class="hero-banner hero-style-12 bg-image photography-banner">
            <div class="swiper photography-activator">
                <div class="swiper-wrapper">
                    <div class="swiper-slide">
                        <img data-transform-origin='center center' data-src="http://127.0.0.1:5500/assets/images/bg/bg-image-39.webp" class="swiper-lazy" alt="image">
                        <div class="thumbnail-bg-content">
                            <div class="banner-content">
                                <div class="title-wrapper">
                                    <h1 class="title">Best Photography <br> Coaching</h1>
                                </div>
                                <div class="content-wrapper">
                                    <p>Excepteur sint occaecat cupidatat non proident sunt <br> in culpa qui officia deserunt mollit.</p>
                                </div>
                                <div class="banner-btn">
                                    <a href="course-details.html" class="edu-btn">Find courses <i class="icon-4"></i></a>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="swiper-slide">
                        <img data-transform-origin='center center' data-src="http://127.0.0.1:5500/assets/images/bg/bg-image-42.webp" class="swiper-lazy" alt="image">
                        <div class="thumbnail-bg-content">
                            <div class="banner-content">
                                <div class="title-wrapper">
                                    <h1 class="title">Best Photography <br> Coaching</h1>
                                </div>
                                <div class="content-wrapper">
                                    <p>Excepteur sint occaecat cupidatat non proident sunt <br> in culpa qui officia deserunt mollit.</p>
                                </div>
                                <div class="banner-btn">
                                    <a href="course-details.html" class="edu-btn">Find courses <i class="icon-4"></i></a>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="swiper-slide">
                        <img data-transform-origin='center center' data-src="http://127.0.0.1:5500/assets/images/bg/bg-image-41.webp" class="swiper-lazy" alt="image">
                        <div class="thumbnail-bg-content">
                            <div class="banner-content">
                                <div class="title-wrapper">
                                    <h1 class="title">Best Photography <br> Coaching</h1>
                                </div>
                                <div class="content-wrapper">
                                    <p>Excepteur sint occaecat cupidatat non proident sunt <br> in culpa qui officia deserunt mollit.</p>
                                </div>
                                <div class="banner-btn">
                                    <a href="course-details.html" class="edu-btn">Find courses <i class="icon-4"></i></a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="swiper-slide-controls slide-prev">
                    <i class="icon-west"></i>
                </div>
                <div class="swiper-slide-controls slide-next">
                    <i class="icon-east"></i>
                </div>

                <div class="pagination-box-wrapper">
                    <div class="pagination-box-wrap">
                        <div class="swiper-pagination"></div>
                    </div>
                </div>
            </div>

        </div>