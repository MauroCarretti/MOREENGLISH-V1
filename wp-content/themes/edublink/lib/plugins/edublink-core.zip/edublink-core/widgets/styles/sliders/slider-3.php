<div class="swiper-container">
    <div class="swiper-wrapper">
        <div class="swiper-slide" style="background-image: url(https://picsum.photos/id/325/700/400/);"><p>Lorem ipsum<br>dolor sit amet</p></div>
        <div class="swiper-slide" style="background-image: url(https://picsum.photos/id/548/700/400/);"><p>Lorem ipsum<br>dolor sit amet</p></div>
        <div class="swiper-slide" style="background-image: url(https://picsum.photos/id/550/700/400/);"><p>Lorem ipsum<br>dolor sit amet</p></div>
    </div>
    <div class="swiper-button-prev"></div>
    <div class="swiper-button-next"></div>
</div>